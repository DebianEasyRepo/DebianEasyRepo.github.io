#!/usr/bin/env bash
tuned-adm profile default
