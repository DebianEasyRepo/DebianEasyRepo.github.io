#include <asm-generic/rwonce.h>
