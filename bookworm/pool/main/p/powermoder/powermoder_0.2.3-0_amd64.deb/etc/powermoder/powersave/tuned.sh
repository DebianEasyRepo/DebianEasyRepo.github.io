#!/usr/bin/env bash
tuned-adm profile laptop-battery-powersave
