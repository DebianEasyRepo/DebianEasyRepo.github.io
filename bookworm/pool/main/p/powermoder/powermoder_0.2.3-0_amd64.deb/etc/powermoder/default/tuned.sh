#!/usr/bin/env bash
tuned-adm auto_profile
