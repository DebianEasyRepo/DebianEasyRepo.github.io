#!/usr/bin/env bash
powerprofilesctl set performance
