#!/usr/bin/env bash
powerprofilesctl set balanced
