#!/usr/bin/env bash
tuned-adm profile laptop-ac-powersave
