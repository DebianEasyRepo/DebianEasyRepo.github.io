#!/usr/bin/env bash
powerprofilesctl set power-saver
