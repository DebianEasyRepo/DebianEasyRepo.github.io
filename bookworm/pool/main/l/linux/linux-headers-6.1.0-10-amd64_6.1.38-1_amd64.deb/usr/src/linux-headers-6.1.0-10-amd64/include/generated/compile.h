#define UTS_MACHINE		"x86_64"
#define LINUX_COMPILE_BY	"debian-kernel"
#define LINUX_COMPILE_HOST	"lists.debian.org"
#define LINUX_COMPILER		"gcc-12 (Debian 12.2.0-14) 12.2.0, GNU ld (GNU Binutils for Debian) 2.40"
